import os
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Student Placement Readiness Analyzer", page_icon="🎓", layout="wide")

DATA_DIR = "data"
FILE_PATH = os.path.join(DATA_DIR, "students.csv")
COLUMNS = ["Name", "Branch", "CGPA", "Aptitude Score", "Skills Score", "Readiness Score", "Status"]


def ensure_data_file():
    os.makedirs(DATA_DIR, exist_ok=True)
    if not os.path.exists(FILE_PATH):
        pd.DataFrame(columns=COLUMNS).to_csv(FILE_PATH, index=False)


def load_data():
    ensure_data_file()
    try:
        df = pd.read_csv(FILE_PATH)
    except pd.errors.EmptyDataError:
        df = pd.DataFrame(columns=COLUMNS)
    for column in COLUMNS:
        if column not in df.columns:
            df[column] = pd.Series(dtype="object")
    return df[COLUMNS]


def save_data(df):
    os.makedirs(DATA_DIR, exist_ok=True)
    df[COLUMNS].to_csv(FILE_PATH, index=False)


def calculate_readiness(cgpa, aptitude, skills):
    cgpa_score = (float(cgpa) / 10.0) * 100.0
    return round(cgpa_score * 0.40 + float(aptitude) * 0.40 + float(skills) * 0.20, 2)


def get_status(score):
    if score >= 70:
        return "Placement Ready"
    if score >= 50:
        return "Needs Improvement"
    return "Needs More Preparation"


st.title("🎓 Student Placement Readiness Analyzer")
st.markdown(
    """
    <div style="display:flex; justify-content:flex-end; margin-top:-1rem; margin-bottom:0.5rem;">
      <span style="font-size:0.95rem; font-weight:700; padding:0.25rem 0.65rem;
      border:1px solid #9CA3AF; border-radius:6px;">CM25112</span>
    </div>
    """,
    unsafe_allow_html=True,
)
st.write("Analyze student placement readiness using CGPA, aptitude, and technical skills.")
st.caption("This score is an educational estimate, not an official company placement decision.")

menu = st.sidebar.radio("Navigation", ["Dashboard", "Add Student", "Manage Records", "Class Analysis"])
df = load_data()

if menu == "Dashboard":
    st.header("Placement Dashboard")
    if df.empty:
        st.info("No student records found. Select 'Add Student' to get started.")
    else:
        df["Readiness Score"] = pd.to_numeric(df["Readiness Score"], errors="coerce")
        col1, col2, col3 = st.columns(3)
        col1.metric("Total Students", len(df))
        col2.metric("Placement Ready", int((df["Readiness Score"] >= 70).sum()))
        col3.metric("Average Readiness", f"{df['Readiness Score'].mean():.2f}%")
        st.subheader("Student Records")
        st.dataframe(df, use_container_width=True, hide_index=True)
        st.subheader("Readiness Scores")
        chart_df = df[["Name", "Readiness Score"]].dropna(subset=["Readiness Score"])
        if not chart_df.empty:
            st.bar_chart(chart_df.set_index("Name"))
        else:
            st.info("No valid readiness scores available yet.")

elif menu == "Add Student":
    st.header("Add Student Details")
    with st.form("student_form", clear_on_submit=True):
        name = st.text_input("Student Name")
        branch = st.selectbox("Branch", ["CSE", "AIML", "IT", "ECE", "Mechanical", "Other"])
        cgpa = st.number_input("CGPA (out of 10)", min_value=0.0, max_value=10.0, value=7.0, step=0.1)
        aptitude = st.slider("Aptitude Score (%)", 0, 100, 60)
        skills = st.slider("Technical Skills Score (%)", 0, 100, 60)
        submitted = st.form_submit_button("Analyze and Save")
    if submitted:
        if not name.strip():
            st.error("Please enter the student's name.")
        else:
            current_df = load_data()
            score = calculate_readiness(cgpa, aptitude, skills)
            new_row = {
                "Name": name.strip(), "Branch": branch, "CGPA": round(float(cgpa), 2),
                "Aptitude Score": int(aptitude), "Skills Score": int(skills),
                "Readiness Score": score, "Status": get_status(score),
            }
            current_df = pd.concat([current_df, pd.DataFrame([new_row], columns=COLUMNS)], ignore_index=True)
            save_data(current_df)
            st.success("Student record saved successfully.")
            st.metric("Readiness Score", f"{score:.2f}%")
            st.write(f"Status: **{get_status(score)}**")

elif menu == "Manage Records":
    st.header("Manage Student Records")
    df = load_data()
    if df.empty:
        st.info("No records available.")
    else:
        st.dataframe(df, use_container_width=True, hide_index=True)
        labels = [f"{i + 1}. {row['Name']} — {row['Branch']} — CGPA {row['CGPA']}" for i, (_, row) in enumerate(df.iterrows())]
        selected = st.selectbox("Select a record to delete", labels)
        if st.button("Delete Selected Record"):
            index = labels.index(selected)
            deleted_name = str(df.iloc[index]["Name"])
            updated = df.drop(df.index[index]).reset_index(drop=True)
            save_data(updated)
            st.success(f"Deleted the record for {deleted_name}.")
            st.rerun()
        st.download_button("Download Student Records CSV", data=df.to_csv(index=False).encode("utf-8"),
                           file_name="students.csv", mime="text/csv")

elif menu == "Class Analysis":
    st.header("Class Performance Analysis")
    df = load_data()
    if df.empty:
        st.info("Add student records to see class analysis.")
    else:
        for column in ["CGPA", "Aptitude Score", "Skills Score", "Readiness Score"]:
            df[column] = pd.to_numeric(df[column], errors="coerce")
        summary = df.groupby("Branch", dropna=False).agg(
            Total_Students=("Name", "count"),
            Average_CGPA=("CGPA", "mean"),
            Average_Readiness=("Readiness Score", "mean"),
        ).round(2)
        st.subheader("Branch-wise Summary")
        st.dataframe(summary, use_container_width=True)
        st.subheader("Readiness Distribution")
        st.bar_chart(df["Status"].value_counts())
        st.subheader("Readiness Criteria")
        st.write("- **70% and above:** Placement Ready")
        st.write("- **50% to below 70%:** Needs Improvement")
        st.write("- **Below 50%:** Needs More Preparation")
