# Student Placement Readiness Analyzer

**Project Code: CM25112**

A Python + Streamlit web application that estimates student placement readiness using CGPA, aptitude, and technical skills.

## Features
- Add student details and calculate an estimated readiness score
- Dashboard metrics and charts
- Manage/delete student records
- Download records as CSV
- Branch-wise class analysis

## Run locally
Use Python 3.10 or newer:

```bash
python -m pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Streamlit Community Cloud
1. Extract this ZIP.
2. Upload `app.py`, `requirements.txt`, `README.md`, and the `data` folder to a GitHub repository.
3. Open https://share.streamlit.io/ and connect GitHub.
4. Select the repository and branch.
5. Set Main file path to `app.py`, then click Deploy.

Important: `app.py` and `requirements.txt` must be in the repository root, not inside an extra nested folder.

## Readiness formula
CGPA contributes 40%, aptitude contributes 40%, and technical skills contribute 20%. These are sample educational weights, not official company criteria.

## Data storage note
Records are stored in `data/students.csv`. CSV storage is suitable for a demo, but cloud hosting may reset local files after restarts or redeployments. Use a persistent database for long-term records.
