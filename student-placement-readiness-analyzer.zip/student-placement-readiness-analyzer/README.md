# Student Placement Readiness Analyzer

A beginner-friendly Python project using Streamlit, NumPy, Pandas, OOP, data structures, and CSV file handling.

## Features
- Add, search, edit, and delete student profiles
- Read and write CSV records with Pandas
- NumPy statistics for CGPA and aptitude scores
- Skill parsing with strings, lists, and sets
- Sample placement eligibility criteria configurable in the sidebar
- Readiness score, charts, and downloadable CSV export
- Fictional demo records for presentation

## Important note
The readiness score and eligibility criteria are educational examples only. They are not official company criteria and do not guarantee placement. Do not enter sensitive personal data. On many free cloud hosts, local CSV files can be reset when an app restarts or redeploys; download backups or use a persistent database for real use.

## Run locally
Requires Python 3.10 or newer.

```bash
python -m venv .venv
```

Activate the environment:
- Windows PowerShell: `.venv\\Scripts\\Activate.ps1`
- macOS/Linux: `source .venv/bin/activate`

Install dependencies and run:

```bash
python -m pip install -r requirements.txt
streamlit run app.py
```

Your browser will open the local app, usually at `http://localhost:8501`.

## Deploy publicly with Streamlit Community Cloud
1. Create a GitHub account if you do not have one.
2. Create a **public** repository named `student-placement-readiness-analyzer`.
3. Upload `app.py`, `requirements.txt`, `README.md`, `.gitignore`, and the `data` folder (including `.gitkeep`). Do not upload real student data.
4. Open https://share.streamlit.io/ and sign in using GitHub.
5. Choose **Create app** and select your repository, branch `main`, and main file path `app.py`.
6. Optionally choose an available app subdomain, then deploy.
7. Wait for the build to finish. Streamlit will show the public `*.streamlit.app` URL when deployment succeeds.
8. Test Add Student, Manage records, Class analysis, and CSV download from the public URL.

Official deployment guide: https://docs.streamlit.io/deploy/streamlit-community-cloud/deploy-your-app/deploy

## Syllabus mapping
- **Module I:** variables, types, expressions, conditions, loops, strings and input widgets
- **Module I (NumPy):** arrays from numeric CSV columns; min, max, mean, median and standard deviation
- **Module II (Functions):** validation, CSV load/save, skill parsing and score methods
- **Module II (Pandas):** CSV import/export, filtering, records and class summaries
- **Module III:** strings, lists, sets, dictionaries, DataFrames and indexing
- **Module IV (File handling):** creating folders, checking files, reading/writing CSV
- **Module IV (OOP):** `Student` and `PlacementAnalyzer` classes

## Readiness score formula
- CGPA contribution: up to 40 points
- Aptitude contribution: up to 40 points
- Skills contribution: up to 20 points (maximum credit for 5 distinct skills)

Score labels: 80+ High readiness; 60–79.9 Moderate readiness; below 60 Needs improvement.
