from pathlib import Path
import pandas as pd
import numpy as np
import streamlit as st

APP_DIR = Path(__file__).parent
DATA_DIR = APP_DIR / "data"
DATA_FILE = DATA_DIR / "students.csv"
COLUMNS = ["roll_no", "name", "department", "cgpa", "aptitude_score", "skills"]


class Student:
    """Represents one student's placement profile."""
    def __init__(self, roll_no, name, department, cgpa, aptitude_score, skills):
        self.roll_no = str(roll_no).strip()
        self.name = str(name).strip()
        self.department = str(department).strip()
        self.cgpa = float(cgpa)
        self.aptitude_score = float(aptitude_score)
        # A set removes duplicate skills; a list is used for predictable display.
        self.skills = sorted({s.strip().title() for s in skills if s.strip()})

    def to_dict(self):
        return {
            "roll_no": self.roll_no,
            "name": self.name,
            "department": self.department,
            "cgpa": self.cgpa,
            "aptitude_score": self.aptitude_score,
            "skills": ", ".join(self.skills),
        }


class PlacementAnalyzer:
    """Uses sample project criteria to assess readiness; not a hiring guarantee."""
    def __init__(self, min_cgpa=7.0, min_aptitude=60.0):
        self.min_cgpa = float(min_cgpa)
        self.min_aptitude = float(min_aptitude)

    def readiness_score(self, cgpa, aptitude_score, skills):
        # Project-defined weighted score: CGPA 40%, aptitude 40%, skills 20%.
        cgpa_component = (float(cgpa) / 10.0) * 40
        aptitude_component = (float(aptitude_score) / 100.0) * 40
        skill_count = len({s.strip().lower() for s in skills if s.strip()})
        skills_component = (min(skill_count, 5) / 5.0) * 20
        return round(cgpa_component + aptitude_component + skills_component, 1)

    def eligible(self, cgpa, aptitude_score):
        return float(cgpa) >= self.min_cgpa and float(aptitude_score) >= self.min_aptitude

    def label(self, score):
        if score >= 80:
            return "High readiness"
        if score >= 60:
            return "Moderate readiness"
        return "Needs improvement"


def ensure_data_file():
    """Create the data folder and CSV header when the file does not exist."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not DATA_FILE.exists():
        pd.DataFrame(columns=COLUMNS).to_csv(DATA_FILE, index=False)


def load_students():
    """Read records from CSV with Pandas; return an empty frame if needed."""
    ensure_data_file()
    try:
        df = pd.read_csv(DATA_FILE, dtype={"roll_no": str})
        for column in COLUMNS:
            if column not in df.columns:
                df[column] = ""
        return df[COLUMNS].fillna("")
    except (pd.errors.EmptyDataError, OSError, pd.errors.ParserError):
        return pd.DataFrame(columns=COLUMNS)


def save_students(df):
    """Write the full student table back to CSV."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    df[COLUMNS].to_csv(DATA_FILE, index=False)


def parse_skills(text):
    """Convert comma-separated skills to a list (string operation)."""
    return [item.strip() for item in text.split(",") if item.strip()]


def valid_student(roll_no, name, department, cgpa, aptitude, skills_text, df, editing_roll=None):
    if not roll_no.strip() or not name.strip() or not department.strip():
        return False, "Roll number, name and department are required."
    if not 0 <= cgpa <= 10:
        return False, "CGPA must be between 0 and 10."
    if not 0 <= aptitude <= 100:
        return False, "Aptitude score must be between 0 and 100."
    if not parse_skills(skills_text):
        return False, "Enter at least one skill, separated by commas."
    duplicates = df["roll_no"].astype(str).str.casefold() == roll_no.strip().casefold()
    if editing_roll is not None:
        duplicates &= df["roll_no"].astype(str) != str(editing_roll)
    if duplicates.any():
        return False, "That roll number already exists. Use a unique roll number."
    return True, "Valid student record."


def make_sample_data():
    """Create clearly labelled fictional demo data."""
    rows = [
        Student("DEMO101", "Aarav Demo", "CSE-AIML", 8.4, 78, ["Python", "SQL", "Communication"]).to_dict(),
        Student("DEMO102", "Isha Demo", "CSE", 7.2, 64, ["Java", "Git", "Problem Solving"]).to_dict(),
        Student("DEMO103", "Kabir Demo", "IT", 6.5, 52, ["HTML", "CSS"]).to_dict(),
    ]
    return pd.DataFrame(rows, columns=COLUMNS)


st.set_page_config(page_title="Placement Readiness Analyzer", page_icon="🎓", layout="wide")
st.title("🎓 Student Placement Readiness Analyzer")
st.caption("Python • NumPy • Pandas • CSV • OOP | Academic demonstration project")
st.info("Readiness scores and eligibility rules are sample project criteria, not official company requirements or a guarantee of placement.")

# Sidebar: editable sample eligibility rules.
st.sidebar.header("Sample eligibility criteria")
min_cgpa = st.sidebar.number_input("Minimum CGPA (0–10)", min_value=0.0, max_value=10.0, value=7.0, step=0.1)
min_aptitude = st.sidebar.number_input("Minimum aptitude score (0–100)", min_value=0.0, max_value=100.0, value=60.0, step=1.0)
analyzer = PlacementAnalyzer(min_cgpa, min_aptitude)

st.sidebar.markdown("---")
st.sidebar.caption("CSV data is stored in data/students.csv. On some cloud hosts, local files may reset after a restart or redeploy. Use fictional data for demos.")

students_df = load_students()
if "notice" in st.session_state:
    st.success(st.session_state.pop("notice"))

# Tabs keep the app easy to demonstrate in a viva.
tab_dashboard, tab_add, tab_manage, tab_analysis = st.tabs(["Dashboard", "Add student", "Manage records", "Class analysis"])

with tab_dashboard:
    st.subheader("Overview")
    if students_df.empty:
        st.write("No student records yet. Add a record or load the fictional demo data below.")
        if st.button("Load fictional demo data", type="primary"):
            save_students(make_sample_data())
            st.session_state["notice"] = "Fictional demo records added. You can delete them from Manage records."
            st.rerun()
    else:
        score_values = []
        labels = []
        eligibility = []
        for _, row in students_df.iterrows():
            skills = parse_skills(str(row["skills"]))
            score = analyzer.readiness_score(row["cgpa"], row["aptitude_score"], skills)
            score_values.append(score)
            labels.append(analyzer.label(score))
            eligibility.append(analyzer.eligible(row["cgpa"], row["aptitude_score"]))
        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Students", len(students_df))
        col2.metric("Average CGPA", f"{pd.to_numeric(students_df['cgpa'], errors='coerce').mean():.2f}")
        col3.metric("Average aptitude", f"{pd.to_numeric(students_df['aptitude_score'], errors='coerce').mean():.1f}/100")
        col4.metric("Meet sample criteria", f"{sum(eligibility)}/{len(eligibility)}")

        display_df = students_df.copy()
        display_df["readiness_score"] = score_values
        display_df["readiness_level"] = labels
        display_df["sample_eligible"] = ["Yes" if item else "No" for item in eligibility]
        st.subheader("Student readiness table")
        st.dataframe(display_df, use_container_width=True, hide_index=True)
        st.download_button("Download student records (CSV)", data=students_df.to_csv(index=False).encode("utf-8"), file_name="student_records.csv", mime="text/csv")

with tab_add:
    st.subheader("Add a student profile")
    with st.form("add_student_form", clear_on_submit=True):
        c1, c2 = st.columns(2)
        roll_no = c1.text_input("Roll number / student ID")
        name = c2.text_input("Student name")
        department = c1.text_input("Department", placeholder="e.g. CSE-AIML")
        cgpa = c2.number_input("CGPA", min_value=0.0, max_value=10.0, value=7.0, step=0.1)
        aptitude = c1.number_input("Aptitude score (0–100)", min_value=0.0, max_value=100.0, value=60.0, step=1.0)
        skills_text = c2.text_input("Skills (comma-separated)", placeholder="Python, SQL, Git")
        submitted = st.form_submit_button("Save student", type="primary")
    if submitted:
        ok, message = valid_student(roll_no, name, department, cgpa, aptitude, skills_text, students_df)
        if ok:
            student = Student(roll_no, name, department, cgpa, aptitude, parse_skills(skills_text))
            updated = pd.concat([students_df, pd.DataFrame([student.to_dict()])], ignore_index=True)
            save_students(updated)
            st.session_state["notice"] = f"Student {student.name} saved successfully."
            st.rerun()
        else:
            st.error(message)

with tab_manage:
    st.subheader("Search, update or delete records")
    if students_df.empty:
        st.write("No records available. Add a student first.")
    else:
        query = st.text_input("Search by roll number, name or department")
        if query.strip():
            mask = students_df.astype(str).apply(lambda col: col.str.contains(query.strip(), case=False, na=False)).any(axis=1)
            filtered_df = students_df[mask]
        else:
            filtered_df = students_df
        st.dataframe(filtered_df, use_container_width=True, hide_index=True)

        choices = students_df["roll_no"].astype(str).tolist()
        selected_roll = st.selectbox("Choose a record to edit or delete", choices)
        selected_rows = students_df[students_df["roll_no"].astype(str) == selected_roll]
        if not selected_rows.empty:
            record = selected_rows.iloc[0]
            with st.expander("Edit selected student"):
                with st.form("edit_student_form"):
                    new_name = st.text_input("Name", value=str(record["name"]))
                    new_department = st.text_input("Department", value=str(record["department"]))
                    new_cgpa = st.number_input("CGPA", min_value=0.0, max_value=10.0, value=float(record["cgpa"]), step=0.1, key="edit_cgpa")
                    new_aptitude = st.number_input("Aptitude score", min_value=0.0, max_value=100.0, value=float(record["aptitude_score"]), step=1.0, key="edit_aptitude")
                    new_skills = st.text_input("Skills (comma-separated)", value=str(record["skills"]))
                    save_edit = st.form_submit_button("Save changes")
                if save_edit:
                    ok, message = valid_student(selected_roll, new_name, new_department, new_cgpa, new_aptitude, new_skills, students_df, editing_roll=selected_roll)
                    if ok:
                        idx = students_df.index[students_df["roll_no"].astype(str) == selected_roll][0]
                        updated = students_df.copy()
                        updated.loc[idx] = Student(selected_roll, new_name, new_department, new_cgpa, new_aptitude, parse_skills(new_skills)).to_dict()
                        save_students(updated)
                        st.session_state["notice"] = f"Record {selected_roll} updated."
                        st.rerun()
                    else:
                        st.error(message)
            confirm = st.checkbox(f"Confirm deletion of {selected_roll}", key="confirm_delete")
            if st.button("Delete selected student", disabled=not confirm):
                updated = students_df[students_df["roll_no"].astype(str) != selected_roll]
                save_students(updated)
                st.session_state["notice"] = f"Record {selected_roll} deleted."
                st.rerun()

with tab_analysis:
    st.subheader("Class-level analysis")
    if students_df.empty:
        st.write("Add students or load fictional demo data to see analysis.")
    else:
        numeric_cgpa = pd.to_numeric(students_df["cgpa"], errors="coerce").dropna().to_numpy(dtype=float)
        numeric_aptitude = pd.to_numeric(students_df["aptitude_score"], errors="coerce").dropna().to_numpy(dtype=float)
        if len(numeric_cgpa):
            a, b, c = st.columns(3)
            a.metric("Highest CGPA", f"{np.max(numeric_cgpa):.2f}")
            b.metric("Lowest CGPA", f"{np.min(numeric_cgpa):.2f}")
            c.metric("Median CGPA", f"{np.median(numeric_cgpa):.2f}")
        if len(numeric_aptitude):
            st.write("**Aptitude score statistics (NumPy):**")
            st.write({"Mean": round(float(np.mean(numeric_aptitude)), 2), "Median": round(float(np.median(numeric_aptitude)), 2), "Standard deviation": round(float(np.std(numeric_aptitude)), 2)})
        chart_df = students_df[["name", "cgpa", "aptitude_score"]].copy()
        chart_df["cgpa"] = pd.to_numeric(chart_df["cgpa"], errors="coerce")
        chart_df["aptitude_score"] = pd.to_numeric(chart_df["aptitude_score"], errors="coerce")
        st.write("**CGPA by student**")
        st.bar_chart(chart_df.set_index("name")[["cgpa"]])
        st.write("**Aptitude score by student**")
        st.bar_chart(chart_df.set_index("name")[["aptitude_score"]])

st.markdown("---")
st.caption("Academic demo only. Avoid entering sensitive personal data. The default CSV file may not be persistent on cloud hosting; export backups when needed.")
